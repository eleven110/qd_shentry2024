# Dynamic Obstacles in Gazebo

This repository contains files which can be used to create dynamic obstacles in the Turtlebot3 House and Cafe Gazebo environments which can used for navigation and motion planning of the robot.

